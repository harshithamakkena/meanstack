class Point {
  x: number;
  y: number;
}

const pointObj = new Point();

pointObj.x = 80;
pointObj.y = 70;

console.log(pointObj);
