var Point = /** @class */ (function () {
    function Point() {
    }
    return Point;
}());
var pointObj = new Point();
pointObj.x = 75;
pointObj.y = 100;
console.log(pointObj);
