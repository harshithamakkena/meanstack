const names: string[] = ['one'];

const namesTuple: [number, string] = [1, 'two'];
