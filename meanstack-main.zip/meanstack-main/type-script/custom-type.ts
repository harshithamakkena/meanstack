type Box = {
  width: number;
  height: number;
};

let bxObj: Box = { width: 100, height: 200 };
