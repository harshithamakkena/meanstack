let rollNumber: any;

rollNumber = 1;
rollNumber = '2A';
rollNumber = true;
