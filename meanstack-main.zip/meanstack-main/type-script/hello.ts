/**
 * 1. create example.ts
 * 2. transpile ts --> js. (tsc example.ts)
 * 3. output: example.js
 * 4. node example.js --> execute js file
 */

console.log('Hello TypeScript');
